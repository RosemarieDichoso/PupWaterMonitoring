<?php
echo password_hash('admin@2468', PASSWORD_DEFAULT);
